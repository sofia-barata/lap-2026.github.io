type quad

val checker_board : int -> quad
val draw : int -> int -> int -> quad -> unit

val rotate : quad -> quad
val mirror : quad -> quad

val parse : string -> quad
val unparse : quad -> string
