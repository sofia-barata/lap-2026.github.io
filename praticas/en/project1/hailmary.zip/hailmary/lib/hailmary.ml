type section = unit

let parse_corridor (_ : string) : section list =
  failwith "unimplemented"

let min_time (_ : section list) : int =
  failwith "unimplemented"